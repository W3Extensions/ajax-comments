=== W3 Ajax Comments ===
Contributors: W3Extensions
Tags: comments, ajax, edit, nested, threaded
Requires at least: 4.7
Tested up to: 5.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Nested/threaded ajax comments for WordPress. Instantly create new comments, post replies and edit existing comments.

== Description ==

Add Disqus-like comment functionality to WordPress. No setup required. Just install and activate.

W3 Comments works perfectly with with cached web pages (so pages don't need to be regenerated/refreshed whenever a new comment is posted).

What's more, you can enable post and comment voting functionality by installing W3 Votify.

== Installation ==

1. Download the plugin zip file from the repository.
2. Upload the zip file directly from Plugins > Add New or extract and upload files to wp-contents/plugins/w3-ajax-comments/ folder via FTP.
3. Activate the plugin.

